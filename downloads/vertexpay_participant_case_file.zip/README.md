# VertexPay Participant Case File

This archive contains the 18 participant document groups for the VertexPay Indian Legal AI Benchmark. Review the documents on their own terms and cite the relevant document numbers in your answer.

No instructor material or answer key is included.
