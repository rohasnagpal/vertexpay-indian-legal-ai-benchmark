# VertexPay Indian Legal Case-Study Benchmark

VertexPay is a synthetic Indian founder/shareholder dispute designed for Legal AI evaluation. The parties, company, transactions and evidence are fictional. Real Indian statutes, rules, regulatory materials and judgments are referenced only in the instructor guide.

## Folder structure

- `participant/` contains the case record. It deliberately includes inconsistent accounts, missing evidence, disputed documents, arithmetic differences and facts favourable to both sides.
- `instructor/` contains hidden ground truth, issue inventory, verified legal source links, expected findings and the scoring rubric. Do not provide it to participants.

## Participant record

The case file contains 18 substantive record groups: 15 detailed DOCX/PDF legal and evidentiary compilations, a WhatsApp export in TXT/PDF, a cap-table/dilution workbook and a bank/payment-record workbook. PDF renditions are provided for convenient review; DOCX/XLSX files remain editable.

## Suggested use

Suitable tasks include chronology building, contract review, company-law issue spotting, NCLT pleading analysis, arbitration/forum analysis, cap-table reconstruction, financial review, investigation planning, electronic-evidence assessment, privilege review, witness preparation, notice drafting and settlement strategy.

## Integrity note

Do not assume that every apparent contradiction has a single correct resolution. Some facts have hidden ground truth; others are deliberately ambiguous. Participant answers should distinguish supplied facts, allegations, inferences, missing evidence and legal conclusions.

## File naming

`VP-01` to `VP-18` are participant materials. The instructor guide is separately labelled `VP-INSTRUCTOR`. The two ZIP archives at the benchmark root package the participant-only set and the complete instructor set respectively.
